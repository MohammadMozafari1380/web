NOTE: This font is FREE FOR PERSONAL USE! 
But any donation are very appreciated. 

Paypal account for donation : https://www.paypal.me/JefriDwiAlfatah

Please visit our store for more premium fonts : 
https://www.creativefabrica.com/designer/bluestype-studio/
https://fontbundles.net/bluestype-studio

Thank You.